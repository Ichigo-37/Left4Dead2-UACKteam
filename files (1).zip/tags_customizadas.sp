#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>
#include <sdktools>

#define PLUGIN_VERSION  "1.0"
#define MAX_TAG_LENGTH  32
#define MAX_NAME_LENGTH 64

// ============================================================
// Configurações ajustáveis (sem precisar recompilar)
// ============================================================
ConVar g_cvDelay;       // segundos após spawnar para exibir mensagem
ConVar g_cvDuration;    // segundos que a mensagem fica na tela

// ============================================================
// Dados dos jogadores em memória
// ============================================================
char g_sTag[MAXPLAYERS+1][MAX_TAG_LENGTH];          // tag atual
char g_sOriginalName[MAXPLAYERS+1][MAX_NAME_LENGTH]; // nome original sem tag

// ============================================================
// Banco de dados
// ============================================================
Database g_hDB;

// ============================================================
// Prefixos reservados para admins
// ============================================================
static const char g_sReservedPrefixes[][] = { "*", "#", "@" };

// ============================================================
// Informações do plugin
// ============================================================
public Plugin myinfo =
{
    name        = "Tags Customizadas",
    author      = "Seu Nome",
    description = "Permite jogadores definirem tags personalizadas no nome",
    version     = PLUGIN_VERSION,
    url         = ""
};

// ============================================================
// Inicialização
// ============================================================
public void OnPluginStart()
{
    // CVars
    g_cvDelay    = CreateConVar("sm_tag_delay",    "10.0", "Segundos após spawnar para exibir a mensagem", FCVAR_NOTIFY);
    g_cvDuration = CreateConVar("sm_tag_duration", "8.0",  "Segundos que a mensagem fica visível na tela",  FCVAR_NOTIFY);

    // Comandos de jogador
    RegConsoleCmd("sm_tag",      Cmd_SetTag,   "Define sua tag: !tag <texto>");
    RegConsoleCmd("sm_cleartag", Cmd_ClearTag, "Remove sua tag");

    // Comandos de admin
    RegAdminCmd("sm_settag",   Cmd_AdminSetTag,   ADMFLAG_GENERIC, "Admin: define tag de um jogador");
    RegAdminCmd("sm_cleartag_player", Cmd_AdminClearTag, ADMFLAG_GENERIC, "Admin: remove tag de um jogador");

    // Banco de dados
    DB_Connect();

    // Carrega config de mensagem
    AutoExecConfig(true, "tags_customizadas");
}

// ============================================================
// Banco de Dados — Conexão e criação da tabela
// ============================================================
void DB_Connect()
{
    char sError[256];
    g_hDB = SQLite_UseDatabase("tags_customizadas", sError, sizeof(sError));

    if (g_hDB == null)
    {
        LogError("Erro ao conectar ao banco de dados: %s", sError);
        return;
    }

    g_hDB.Query(DB_OnTableCreated,
        "CREATE TABLE IF NOT EXISTS player_tags ( \
            steamid TEXT PRIMARY KEY, \
            tag     TEXT NOT NULL \
        )");
}

public void DB_OnTableCreated(Database db, DBResultSet results, const char[] error, any data)
{
    if (results == null)
        LogError("Erro ao criar tabela: %s", error);
}

// ============================================================
// Jogador entra no servidor — carrega tag salva
// ============================================================
public void OnClientPutInServer(int client)
{
    if (!IsValidClient(client))
        return;

    g_sTag[client][0]          = '\0';
    g_sOriginalName[client][0] = '\0';

    GetClientName(client, g_sOriginalName[client], MAX_NAME_LENGTH);

    DB_LoadTag(client);
}

public void OnClientDisconnect(int client)
{
    g_sTag[client][0]          = '\0';
    g_sOriginalName[client][0] = '\0';
}

// ============================================================
// Carrega tag do banco de dados
// ============================================================
void DB_LoadTag(int client)
{
    if (g_hDB == null)
        return;

    char sSteamID[32];
    if (!GetClientAuthId(client, AuthId_Steam2, sSteamID, sizeof(sSteamID)))
        return;

    char sQuery[256];
    Format(sQuery, sizeof(sQuery), "SELECT tag FROM player_tags WHERE steamid = '%s'", sSteamID);

    DataPack dp = new DataPack();
    dp.WriteCell(GetClientUserId(client));

    g_hDB.Query(DB_OnTagLoaded, sQuery, dp);
}

public void DB_OnTagLoaded(Database db, DBResultSet results, const char[] error, DataPack dp)
{
    dp.Reset();
    int userid = dp.ReadCell();
    delete dp;

    int client = GetClientOfUserId(userid);
    if (client == 0 || !IsValidClient(client))
        return;

    if (results == null)
    {
        LogError("Erro ao carregar tag: %s", error);
        return;
    }

    if (results.FetchRow())
    {
        char sTag[MAX_TAG_LENGTH];
        results.FetchString(0, sTag, sizeof(sTag));
        strcopy(g_sTag[client], MAX_TAG_LENGTH, sTag);
        ApplyTag(client);
    }
}

// ============================================================
// Salva tag no banco de dados
// ============================================================
void DB_SaveTag(int client, const char[] sTag)
{
    if (g_hDB == null)
        return;

    char sSteamID[32];
    if (!GetClientAuthId(client, AuthId_Steam2, sSteamID, sizeof(sSteamID)))
        return;

    char sQuery[256];
    Format(sQuery, sizeof(sQuery),
        "INSERT OR REPLACE INTO player_tags (steamid, tag) VALUES ('%s', '%s')",
        sSteamID, sTag);

    g_hDB.Query(DB_OnTagSaved, sQuery);
}

public void DB_OnTagSaved(Database db, DBResultSet results, const char[] error, any data)
{
    if (results == null)
        LogError("Erro ao salvar tag: %s", error);
}

// ============================================================
// Remove tag do banco de dados
// ============================================================
void DB_DeleteTag(int client)
{
    if (g_hDB == null)
        return;

    char sSteamID[32];
    if (!GetClientAuthId(client, AuthId_Steam2, sSteamID, sizeof(sSteamID)))
        return;

    char sQuery[256];
    Format(sQuery, sizeof(sQuery), "DELETE FROM player_tags WHERE steamid = '%s'", sSteamID);

    g_hDB.Query(DB_OnTagDeleted, sQuery);
}

public void DB_OnTagDeleted(Database db, DBResultSet results, const char[] error, any data)
{
    if (results == null)
        LogError("Erro ao deletar tag: %s", error);
}

// ============================================================
// Aplica a tag no nome do jogador
// ============================================================
void ApplyTag(int client)
{
    if (!IsValidClient(client))
        return;

    char sNewName[MAX_NAME_LENGTH];

    if (g_sTag[client][0] != '\0')
        Format(sNewName, sizeof(sNewName), "[%s] %s", g_sTag[client], g_sOriginalName[client]);
    else
        strcopy(sNewName, MAX_NAME_LENGTH, g_sOriginalName[client]);

    SetClientName(client, sNewName);
}

// ============================================================
// Evento: jogador spawna — exibe mensagem após delay
// ============================================================
public void OnClientSpawnPost(int client)
{
    if (!IsValidClient(client))
        return;

    float fDelay = g_cvDelay.FloatValue;
    CreateTimer(fDelay, Timer_ShowWelcomeMsg, GetClientUserId(client));
}

public Action Timer_ShowWelcomeMsg(Handle timer, int userid)
{
    int client = GetClientOfUserId(userid);
    if (client == 0 || !IsValidClient(client))
        return Plugin_Stop;

    // Lê as linhas de mensagem do arquivo de configuração
    char sLine1[128], sLine2[128], sLine3[128], sLine4[128];
    LoadMessageLines(sLine1, sLine2, sLine3, sLine4);

    float fDuration = g_cvDuration.FloatValue;

    // Exibe a mensagem repetida para simular duração (HintText some após ~5s)
    // Usamos um timer repetitivo pelo tempo configurado
    DataPack dp = new DataPack();
    dp.WriteCell(userid);
    dp.WriteString(sLine1);
    dp.WriteString(sLine2);
    dp.WriteString(sLine3);
    dp.WriteString(sLine4);
    dp.WriteFloat(GetGameTime() + fDuration);

    CreateTimer(0.1, Timer_RepeatMsg, dp, TIMER_REPEAT | TIMER_DATA_HNDL_CLOSE);

    return Plugin_Stop;
}

public Action Timer_RepeatMsg(Handle timer, DataPack dp)
{
    dp.Reset();
    int userid   = dp.ReadCell();
    char sLine1[128]; dp.ReadString(sLine1, sizeof(sLine1));
    char sLine2[128]; dp.ReadString(sLine2, sizeof(sLine2));
    char sLine3[128]; dp.ReadString(sLine3, sizeof(sLine3));
    char sLine4[128]; dp.ReadString(sLine4, sizeof(sLine4));
    float fEndTime = dp.ReadFloat();

    if (GetGameTime() >= fEndTime)
        return Plugin_Stop;

    int client = GetClientOfUserId(userid);
    if (client == 0 || !IsValidClient(client))
        return Plugin_Stop;

    PrintHintText(client, "%s\n%s\n%s\n%s", sLine1, sLine2, sLine3, sLine4);

    return Plugin_Continue;
}

// ============================================================
// Carrega as linhas da mensagem do arquivo .cfg
// ============================================================
void LoadMessageLines(char[] sLine1, char[] sLine2, char[] sLine3, char[] sLine4)
{
    char sPath[PLATFORM_MAX_PATH];
    BuildPath(Path_SM, sPath, sizeof(sPath), "configs/tags_mensagem.cfg");

    KeyValues kv = new KeyValues("mensagem");

    if (!kv.ImportFromFile(sPath))
    {
        // Mensagem padrão se o arquivo não existir
        strcopy(sLine1, 128, "Personalize seu nome! / ¡Personaliza tu nombre!");
        strcopy(sLine2, 128, "!tag <texto>  →  [tag] SeuNome");
        strcopy(sLine3, 128, "!cleartag     →  remove a tag / elimina el tag");
        strcopy(sLine4, 128, "");
        delete kv;
        return;
    }

    kv.GetString("linha1", sLine1, 128, "Personalize seu nome! / ¡Personaliza tu nombre!");
    kv.GetString("linha2", sLine2, 128, "!tag <texto>  →  [tag] SeuNome");
    kv.GetString("linha3", sLine3, 128, "!cleartag     →  remove a tag / elimina el tag");
    kv.GetString("linha4", sLine4, 128, "");

    delete kv;
}

// ============================================================
// Validações
// ============================================================
bool IsTagAllowed(int client, const char[] sTag)
{
    // Admins podem usar qualquer tag
    if (CheckCommandAccess(client, "sm_settag", ADMFLAG_GENERIC))
        return true;

    // Verifica palavras proibidas (arquivo de configuração)
    char sPath[PLATFORM_MAX_PATH];
    BuildPath(Path_SM, sPath, sizeof(sPath), "configs/tags_proibidas.cfg");

    KeyValues kv = new KeyValues("proibidas");
    if (kv.ImportFromFile(sPath))
    {
        if (kv.GotoFirstSubKey(false))
        {
            do
            {
                char sProibida[64];
                kv.GetString(NULL_STRING, sProibida, sizeof(sProibida));

                char sTagLower[MAX_TAG_LENGTH];
                strcopy(sTagLower, sizeof(sTagLower), sTag);
                // Comparação case-insensitive
                if (StrContains(sTagLower, sProibida, false) != -1)
                {
                    delete kv;
                    return false;
                }
            }
            while (kv.GotoNextKey(false));
        }
    }
    delete kv;

    // Verifica prefixos reservados para admins
    for (int i = 0; i < sizeof(g_sReservedPrefixes); i++)
    {
        if (strncmp(sTag, g_sReservedPrefixes[i], strlen(g_sReservedPrefixes[i])) == 0)
            return false;
    }

    return true;
}

// ============================================================
// Comando !tag <texto>
// ============================================================
public Action Cmd_SetTag(int client, int args)
{
    if (client == 0)
    {
        ReplyToCommand(client, "[Tags] Comando disponível apenas para jogadores.");
        return Plugin_Handled;
    }

    if (args < 1)
    {
        PrintToChat(client, " \x04[Tags]\x01 Use: !tag <texto>");
        return Plugin_Handled;
    }

    char sTag[MAX_TAG_LENGTH];
    GetCmdArg(1, sTag, sizeof(sTag));

    // Remove espaços extras
    TrimString(sTag);

    if (strlen(sTag) == 0)
    {
        PrintToChat(client, " \x04[Tags]\x01 Tag inválida.");
        return Plugin_Handled;
    }

    if (strlen(sTag) > 20)
    {
        PrintToChat(client, " \x04[Tags]\x01 Tag muito longa. Máximo 20 caracteres.");
        return Plugin_Handled;
    }

    if (!IsTagAllowed(client, sTag))
    {
        PrintToChat(client, " \x04[Tags]\x01 Essa tag não é permitida.");
        return Plugin_Handled;
    }

    strcopy(g_sTag[client], MAX_TAG_LENGTH, sTag);
    ApplyTag(client);
    DB_SaveTag(client, sTag);

    PrintToChat(client, " \x04[Tags]\x01 Tag definida: \x05[%s]\x01 %s", sTag, g_sOriginalName[client]);

    return Plugin_Handled;
}

// ============================================================
// Comando !cleartag
// ============================================================
public Action Cmd_ClearTag(int client, int args)
{
    if (client == 0)
    {
        ReplyToCommand(client, "[Tags] Comando disponível apenas para jogadores.");
        return Plugin_Handled;
    }

    g_sTag[client][0] = '\0';
    ApplyTag(client);
    DB_DeleteTag(client);

    PrintToChat(client, " \x04[Tags]\x01 Tag removida.");

    return Plugin_Handled;
}

// ============================================================
// Comando admin: sm_settag <jogador> <tag>
// ============================================================
public Action Cmd_AdminSetTag(int client, int args)
{
    if (args < 2)
    {
        ReplyToCommand(client, "[Tags] Use: sm_settag <jogador> <tag>");
        return Plugin_Handled;
    }

    char sTarget[64];
    GetCmdArg(1, sTarget, sizeof(sTarget));

    char sTag[MAX_TAG_LENGTH];
    GetCmdArg(2, sTag, sizeof(sTag));
    TrimString(sTag);

    int target = FindTarget(client, sTarget, true, false);
    if (target == -1)
        return Plugin_Handled;

    strcopy(g_sTag[target], MAX_TAG_LENGTH, sTag);
    ApplyTag(target);
    DB_SaveTag(target, sTag);

    ReplyToCommand(client, "[Tags] Tag de %N definida para [%s].", target, sTag);
    PrintToChat(target, " \x04[Tags]\x01 Um admin definiu sua tag para: \x05[%s]", sTag);

    return Plugin_Handled;
}

// ============================================================
// Comando admin: sm_cleartag_player <jogador>
// ============================================================
public Action Cmd_AdminClearTag(int client, int args)
{
    if (args < 1)
    {
        ReplyToCommand(client, "[Tags] Use: sm_cleartag_player <jogador>");
        return Plugin_Handled;
    }

    char sTarget[64];
    GetCmdArg(1, sTarget, sizeof(sTarget));

    int target = FindTarget(client, sTarget, true, false);
    if (target == -1)
        return Plugin_Handled;

    g_sTag[target][0] = '\0';
    ApplyTag(target);
    DB_DeleteTag(target);

    ReplyToCommand(client, "[Tags] Tag de %N removida.", target);
    PrintToChat(target, " \x04[Tags]\x01 Um admin removeu sua tag.");

    return Plugin_Handled;
}

// ============================================================
// Evento spawn (hook)
// ============================================================
public void OnClientSpawn_Post(Event event, const char[] name, bool dontBroadcast)
{
    int client = GetClientOfUserId(event.GetInt("userid"));
    if (IsValidClient(client))
        OnClientSpawnPost(client);
}

public void OnMapStart()
{
    // Reaplica tags de todos ao trocar/reiniciar capítulo
    for (int i = 1; i <= MaxClients; i++)
    {
        if (IsValidClient(i) && g_sTag[i][0] != '\0')
            ApplyTag(i);
    }
}

// ============================================================
// Utilitário
// ============================================================
bool IsValidClient(int client)
{
    return (client > 0 && client <= MaxClients && IsClientInGame(client) && !IsFakeClient(client));
}
