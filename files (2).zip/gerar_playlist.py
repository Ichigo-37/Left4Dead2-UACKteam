#!/usr/bin/env python3
"""
gerar_playlist.py — Mika e PV
Escaneia a pasta de músicas e gera o playlist.txt automaticamente.

Uso:
    python gerar_playlist.py

Coloque este script na raiz do servidor ou ajuste o SOUND_DIR abaixo.
"""

import os
import sys

# ─── Configuração ────────────────────────────────────────────
# Caminho até a pasta sound/musicas/ relativo a onde o script está
SOUND_DIR   = os.path.join("sound", "musicas")

# Onde salvar o playlist.txt gerado
OUTPUT_FILE = os.path.join(
    "addons", "sourcemod", "configs", "musicas", "playlist.txt"
)

# Extensões aceitas
EXTENSIONS = {".mp3", ".wav"}
# ─────────────────────────────────────────────────────────────


def format_name(filename: str) -> str:
    """Converte nome de arquivo em nome de exibição legível."""
    name = os.path.splitext(filename)[0]
    name = name.replace("_", " ").replace("-", " ")
    return name.title()


def scan_songs(base_dir: str):
    """
    Escaneia subpastas de base_dir.
    Cada subpasta é tratada como uma categoria.
    Retorna lista de tuplas: (categoria, nome_exibição, caminho_relativo)
    """
    songs = []

    if not os.path.isdir(base_dir):
        print(f"[ERRO] Pasta não encontrada: {base_dir}")
        sys.exit(1)

    for entry in sorted(os.scandir(base_dir), key=lambda e: e.name):
        if not entry.is_dir():
            continue

        category = entry.name.title()

        for file in sorted(os.scandir(entry.path), key=lambda e: e.name):
            if not file.is_file():
                continue
            ext = os.path.splitext(file.name)[1].lower()
            if ext not in EXTENSIONS:
                continue

            # Caminho relativo ao sound/ (sem "sound/")
            rel_path = os.path.join(entry.name, file.name).replace("\\", "/")
            display  = format_name(file.name)

            songs.append((category, display, rel_path))

    return songs


def write_playlist(songs, output_path: str):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("# Playlist gerada automaticamente por gerar_playlist.py\n")
        f.write("# Mika e PV\n")
        f.write("# Formato: categoria|nome de exibição|arquivo|duração_segundos\n")
        f.write("# A duração foi omitida — edite manualmente se quiser o tempo total no HUD\n\n")

        current_cat = None
        for category, display, path in songs:
            if category != current_cat:
                f.write(f"\n# ── {category} ──\n")
                current_cat = category
            f.write(f"{category}|{display}|{path}\n")

    print(f"[OK] playlist.txt gerado com {len(songs)} músicas em: {output_path}")


if __name__ == "__main__":
    print(f"Escaneando: {os.path.abspath(SOUND_DIR)}")
    songs = scan_songs(SOUND_DIR)

    if not songs:
        print("[AVISO] Nenhuma música encontrada. Verifique o SOUND_DIR no script.")
        sys.exit(0)

    write_playlist(songs, OUTPUT_FILE)
    print("\nCategorias encontradas:")
    cats = sorted(set(s[0] for s in songs))
    for cat in cats:
        count = sum(1 for s in songs if s[0] == cat)
        print(f"  {cat}: {count} música(s)")
