/**
 * music_player.sp
 * Plugin: L4D2 Music Player
 * Autor: Mika e PV
 * Versão: 1.0
 *
 * Funcionalidades:
 * - Player de músicas com menu por categoria/pasta
 * - Tocar para si mesmo, para todos ou para jogador específico
 * - HUD Text fixo no canto inferior esquerdo mostrando música atual
 * - Notificação no chat + HintText quando música começa
 * - Bloqueia música do Tank e exibe aviso na tela
 * - Sistema de letras sincronizadas (desativado por padrão)
 * - FastDL preparado via AddFileToDownloadsTable
 */

#include <sourcemod>
#include <sdktools>
#include <clientprefs>

#pragma semicolon 1
#pragma newdecls required

// ============================================================
// Constantes
// ============================================================
#define PLUGIN_VERSION      "1.0"
#define MAX_SONGS           256
#define MAX_CATEGORIES      32
#define MAX_LYRICS_LINES    256
#define SOUND_BASE          "musicas/"
#define PLAYLIST_FILE       "configs/musicas/playlist.txt"
#define LYRICS_DIR          "configs/musicas/letras/"
#define HUD_CHANNEL         3
#define HUD_X               0.01   // canto esquerdo
#define HUD_Y               0.85   // perto do chat (inferior)

// ============================================================
// Estruturas
// ============================================================
enum struct SongData
{
    char category[64];
    char displayName[128];
    char filePath[PLATFORM_MAX_PATH];
    float duration;   // em segundos (0 = desconhecido)
}

enum struct LyricLine
{
    float timestamp;
    char text[256];
}

// ============================================================
// Variáveis globais
// ============================================================

// Biblioteca de músicas
SongData g_Songs[MAX_SONGS];
int      g_SongCount = 0;

// Categorias únicas
char g_Categories[MAX_CATEGORIES][64];
int  g_CategoryCount = 0;

// Estado por cliente
int   g_CurrentSong[MAXPLAYERS+1];      // índice da música tocando (-1 = nenhuma)
bool  g_ShowHUD[MAXPLAYERS+1];          // exibir HUD text?
float g_SongStartTime[MAXPLAYERS+1];    // GetGameTime() quando a música começou
Handle g_SongTimer[MAXPLAYERS+1];       // timer de duração da música
int   g_TargetMode[MAXPLAYERS+1];       // 0=self 1=all 2=specific (contexto do menu)
int   g_TargetPlayer[MAXPLAYERS+1];     // alvo quando modo=2

// HUD
Handle g_HudSync = null;

// Letras
LyricLine g_Lyrics[MAX_LYRICS_LINES];
int       g_LyricCount = 0;
Handle    g_LyricTimers[MAX_LYRICS_LINES];
int       g_LyricTarget = -1;           // -1 = todos, senão client index

// Tank
bool g_TankAlive = false;

// ConVars
ConVar g_cvEnabled;
ConVar g_cvAdminBlock;
ConVar g_cvShowHUDDefault;
ConVar g_cvLyricsEnabled;
ConVar g_cvTankMessage;
ConVar g_cvTankDeadMessage;
ConVar g_cvNotifyChat;
ConVar g_cvNotifyHint;

// ============================================================
// Informações do Plugin
// ============================================================
public Plugin myinfo =
{
    name        = "L4D2 Music Player",
    author      = "Mika e PV",
    description = "Player de músicas com menu, HUD e eventos de Tank",
    version     = PLUGIN_VERSION,
    url         = ""
};

// ============================================================
// OnPluginStart
// ============================================================
public void OnPluginStart()
{
    // ConVars
    g_cvEnabled         = CreateConVar("sm_music_enabled",          "1",    "Habilita/desabilita o Music Player", FCVAR_NOTIFY);
    g_cvAdminBlock      = CreateConVar("sm_music_admin_block",       "0",    "1 = bloqueia uso por jogadores normais (só admins)", FCVAR_NOTIFY);
    g_cvShowHUDDefault  = CreateConVar("sm_music_hud_default",       "1",    "HUD de música visível por padrão para novos jogadores");
    g_cvLyricsEnabled   = CreateConVar("sm_music_lyrics_enabled",    "0",    "Habilita sistema de letras sincronizadas");
    g_cvTankMessage     = CreateConVar("sm_music_tank_msg",          "⚠ TANK!", "Mensagem exibida quando Tank spawna");
    g_cvTankDeadMessage = CreateConVar("sm_music_tankdead_msg",      "✔ Tank eliminado!", "Mensagem exibida quando Tank morre");
    g_cvNotifyChat      = CreateConVar("sm_music_notify_chat",       "1",    "Notifica no chat quando música começa");
    g_cvNotifyHint      = CreateConVar("sm_music_notify_hint",       "1",    "Notifica com HintText quando música começa");

    AutoExecConfig(true, "music_player");

    // Comandos
    RegConsoleCmd("sm_musica",   Cmd_OpenMenu,   "Abre o menu do Music Player");
    RegConsoleCmd("sm_stopm",    Cmd_StopMusic,  "Para a música atual");
    RegConsoleCmd("sm_hudm",     Cmd_ToggleHUD,  "Liga/desliga o HUD de música");
    RegAdminCmd("sm_musicblock", Cmd_AdminBlock, ADMFLAG_GENERIC, "Bloqueia/desbloqueia uso do Music Player por jogadores");

    // Eventos de Tank
    HookEvent("tank_spawn",  Event_TankSpawn);
    HookEvent("tank_killed", Event_TankKilled);

    // HUD
    g_HudSync = CreateHudSynchronizer();

    // Inicializa estado
    for (int i = 1; i <= MaxClients; i++)
    {
        g_CurrentSong[i]   = -1;
        g_ShowHUD[i]       = true;
        g_SongTimer[i]     = null;
        g_SongStartTime[i] = 0.0;
    }

    LoadPlaylist();
}

// ============================================================
// OnMapStart — precache e fastDL
// ============================================================
public void OnMapStart()
{
    for (int i = 0; i < g_SongCount; i++)
    {
        char fullPath[PLATFORM_MAX_PATH];
        Format(fullPath, sizeof(fullPath), "%s%s", SOUND_BASE, g_Songs[i].filePath);

        PrecacheSound(fullPath, true);
        AddFileToDownloadsTable(fullPath); // fastDL (preparado, ativar quando necessário)
    }
}

// ============================================================
// OnClientPutInServer
// ============================================================
public void OnClientPutInServer(int client)
{
    g_CurrentSong[client]   = -1;
    g_ShowHUD[client]       = g_cvShowHUDDefault.BoolValue;
    g_SongTimer[client]     = null;
    g_SongStartTime[client] = 0.0;
}

// ============================================================
// OnClientDisconnect
// ============================================================
public void OnClientDisconnect(int client)
{
    StopClientMusic(client);
}

// ============================================================
// Carregar playlist
// ============================================================
void LoadPlaylist()
{
    g_SongCount     = 0;
    g_CategoryCount = 0;

    char path[PLATFORM_MAX_PATH];
    BuildPath(Path_SM, path, sizeof(path), PLAYLIST_FILE);

    File f = OpenFile(path, "r");
    if (f == null)
    {
        LogError("[MusicPlayer] Arquivo de playlist não encontrado: %s", path);
        return;
    }

    char line[512];
    while (f.ReadLine(line, sizeof(line)) && g_SongCount < MAX_SONGS)
    {
        TrimString(line);
        if (line[0] == '\0' || line[0] == '/' || line[0] == '#')
            continue;

        // Formato: categoria|nome de exibição|arquivo.mp3|duração_segundos
        // duração é opcional
        char parts[4][PLATFORM_MAX_PATH];
        int count = ExplodeString(line, "|", parts, 4, PLATFORM_MAX_PATH);
        if (count < 3) continue;

        strcopy(g_Songs[g_SongCount].category,    64,                  parts[0]);
        strcopy(g_Songs[g_SongCount].displayName, 128,                 parts[1]);
        strcopy(g_Songs[g_SongCount].filePath,    PLATFORM_MAX_PATH,   parts[2]);
        g_Songs[g_SongCount].duration = (count >= 4) ? StringToFloat(parts[3]) : 0.0;

        // Registra categoria única
        AddCategoryIfNew(parts[0]);

        g_SongCount++;
    }
    delete f;

    LogMessage("[MusicPlayer] %d músicas carregadas em %d categorias.", g_SongCount, g_CategoryCount);
}

void AddCategoryIfNew(const char[] cat)
{
    for (int i = 0; i < g_CategoryCount; i++)
        if (StrEqual(g_Categories[i], cat, false))
            return;

    if (g_CategoryCount < MAX_CATEGORIES)
        strcopy(g_Categories[g_CategoryCount++], 64, cat);
}

// ============================================================
// Comandos
// ============================================================
public Action Cmd_OpenMenu(int client, int args)
{
    if (!client) return Plugin_Handled;
    if (!g_cvEnabled.BoolValue)
    {
        PrintToChat(client, "\x01[Music] \x04Plugin desativado.");
        return Plugin_Handled;
    }
    if (g_cvAdminBlock.BoolValue && !CheckCommandAccess(client, "sm_musicblock", ADMFLAG_GENERIC))
    {
        PrintToChat(client, "\x01[Music] \x04Uso bloqueado pelo administrador.");
        return Plugin_Handled;
    }

    Menu_OpenMain(client);
    return Plugin_Handled;
}

public Action Cmd_StopMusic(int client, int args)
{
    if (!client) return Plugin_Handled;
    StopClientMusic(client);
    PrintToChat(client, "\x01[Music] \x04Música parada.");
    return Plugin_Handled;
}

public Action Cmd_ToggleHUD(int client, int args)
{
    if (!client) return Plugin_Handled;
    g_ShowHUD[client] = !g_ShowHUD[client];
    PrintToChat(client, "\x01[Music] HUD \x04%s\x01.", g_ShowHUD[client] ? "ativado" : "desativado");
    if (!g_ShowHUD[client])
        ClearSyncHud(client, g_HudSync);
    return Plugin_Handled;
}

public Action Cmd_AdminBlock(int client, int args)
{
    bool current = g_cvAdminBlock.BoolValue;
    g_cvAdminBlock.SetBool(!current);
    ReplyToCommand(client, "[Music] Bloqueio para jogadores normais: %s", !current ? "ATIVADO" : "DESATIVADO");
    return Plugin_Handled;
}

// ============================================================
// Menus
// ============================================================

// Menu principal: Para mim / Para todos / Para um jogador
void Menu_OpenMain(int client)
{
    Menu menu = new Menu(MenuHandler_Main);
    menu.SetTitle("♪ Music Player");
    menu.AddItem("self", "🎵 Para mim");
    menu.AddItem("all",  "🌐 Para todos");
    menu.AddItem("player", "👤 Para um jogador");
    menu.AddItem("stop", "⏹ Parar música");
    menu.AddItem("hud",  "👁 Ligar/desligar HUD");
    menu.Display(client, MENU_TIME_FOREVER);
}

public int MenuHandler_Main(Menu menu, MenuAction action, int client, int param2)
{
    if (action == MenuAction_Select)
    {
        char info[16];
        menu.GetItem(param2, info, sizeof(info));

        if (StrEqual(info, "self"))
        {
            g_TargetMode[client] = 0;
            Menu_OpenCategories(client);
        }
        else if (StrEqual(info, "all"))
        {
            if (!CheckCommandAccess(client, "sm_musicblock", ADMFLAG_GENERIC) && g_cvAdminBlock.BoolValue)
            {
                PrintToChat(client, "\x01[Music] \x04Sem permissão para tocar para todos.");
                return 0;
            }
            g_TargetMode[client] = 1;
            Menu_OpenCategories(client);
        }
        else if (StrEqual(info, "player"))
        {
            if (!CheckCommandAccess(client, "sm_musicblock", ADMFLAG_GENERIC) && g_cvAdminBlock.BoolValue)
            {
                PrintToChat(client, "\x01[Music] \x04Sem permissão para tocar para outros jogadores.");
                return 0;
            }
            g_TargetMode[client] = 2;
            Menu_OpenPlayerList(client);
        }
        else if (StrEqual(info, "stop"))
        {
            StopClientMusic(client);
            PrintToChat(client, "\x01[Music] \x04Música parada.");
        }
        else if (StrEqual(info, "hud"))
        {
            g_ShowHUD[client] = !g_ShowHUD[client];
            PrintToChat(client, "\x01[Music] HUD \x04%s\x01.", g_ShowHUD[client] ? "ativado" : "desativado");
            if (!g_ShowHUD[client])
                ClearSyncHud(client, g_HudSync);
        }
    }
    else if (action == MenuAction_End)
        delete menu;

    return 0;
}

// Menu de categorias
void Menu_OpenCategories(int client)
{
    Menu menu = new Menu(MenuHandler_Categories);
    menu.SetTitle("♪ Escolha a categoria");
    menu.ExitBackButton = true;

    for (int i = 0; i < g_CategoryCount; i++)
        menu.AddItem(g_Categories[i], g_Categories[i]);

    menu.Display(client, MENU_TIME_FOREVER);
}

public int MenuHandler_Categories(Menu menu, MenuAction action, int client, int param2)
{
    if (action == MenuAction_Select)
    {
        char cat[64];
        menu.GetItem(param2, cat, sizeof(cat));
        Menu_OpenSongs(client, cat);
    }
    else if (action == MenuAction_Cancel && param2 == MenuCancel_ExitBack)
        Menu_OpenMain(client);
    else if (action == MenuAction_End)
        delete menu;

    return 0;
}

// Menu de músicas por categoria
void Menu_OpenSongs(int client, const char[] category)
{
    Menu menu = new Menu(MenuHandler_Songs);
    menu.SetTitle("♪ %s", category);
    menu.ExitBackButton = true;

    char idx[8];
    for (int i = 0; i < g_SongCount; i++)
    {
        if (StrEqual(g_Songs[i].category, category, false))
        {
            IntToString(i, idx, sizeof(idx));
            menu.AddItem(idx, g_Songs[i].displayName);
        }
    }

    menu.Display(client, MENU_TIME_FOREVER);
}

public int MenuHandler_Songs(Menu menu, MenuAction action, int client, int param2)
{
    if (action == MenuAction_Select)
    {
        char idx[8];
        menu.GetItem(param2, idx, sizeof(idx));
        int songIdx = StringToInt(idx);

        switch (g_TargetMode[client])
        {
            case 0: PlayMusicTo(client, client, songIdx);
            case 1: PlayMusicToAll(client, songIdx);
            case 2: PlayMusicTo(client, g_TargetPlayer[client], songIdx);
        }
    }
    else if (action == MenuAction_Cancel && param2 == MenuCancel_ExitBack)
        Menu_OpenCategories(client);
    else if (action == MenuAction_End)
        delete menu;

    return 0;
}

// Lista de jogadores
void Menu_OpenPlayerList(int client)
{
    Menu menu = new Menu(MenuHandler_PlayerList);
    menu.SetTitle("♪ Escolha o jogador");
    menu.ExitBackButton = true;

    char idx[8], name[MAX_NAME_LENGTH];
    for (int i = 1; i <= MaxClients; i++)
    {
        if (!IsClientInGame(i) || i == client) continue;
        IntToString(i, idx, sizeof(idx));
        GetClientName(i, name, sizeof(name));
        menu.AddItem(idx, name);
    }

    menu.Display(client, MENU_TIME_FOREVER);
}

public int MenuHandler_PlayerList(Menu menu, MenuAction action, int client, int param2)
{
    if (action == MenuAction_Select)
    {
        char idx[8];
        menu.GetItem(param2, idx, sizeof(idx));
        g_TargetPlayer[client] = StringToInt(idx);
        Menu_OpenCategories(client);
    }
    else if (action == MenuAction_Cancel && param2 == MenuCancel_ExitBack)
        Menu_OpenMain(client);
    else if (action == MenuAction_End)
        delete menu;

    return 0;
}

// ============================================================
// Reprodução de música
// ============================================================
void PlayMusicTo(int requester, int target, int songIdx)
{
    if (!IsClientInGame(target)) return;

    StopClientMusic(target);

    char fullPath[PLATFORM_MAX_PATH];
    Format(fullPath, sizeof(fullPath), "%s%s", SOUND_BASE, g_Songs[songIdx].filePath);

    EmitSoundToClient(target, fullPath, SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL);

    g_CurrentSong[target]   = songIdx;
    g_SongStartTime[target] = GetGameTime();

    // Notificações
    NotifyMusicStart(target, songIdx, requester);

    // Timer de duração (se informada)
    if (g_Songs[songIdx].duration > 0.0)
    {
        DataPack dp = new DataPack();
        dp.WriteCell(target);
        dp.WriteCell(songIdx);
        g_SongTimer[target] = CreateDataTimer(g_Songs[songIdx].duration, Timer_SongEnd, dp);
    }

    // Letras (se habilitado)
    if (g_cvLyricsEnabled.BoolValue)
    {
        LoadAndScheduleLyrics(songIdx, target);
    }

    // HUD contínuo
    CreateTimer(0.1, Timer_UpdateHUD, target, TIMER_REPEAT | TIMER_FLAG_NO_MAPCHANGE);
}

void PlayMusicToAll(int requester, int songIdx)
{
    char fullPath[PLATFORM_MAX_PATH];
    Format(fullPath, sizeof(fullPath), "%s%s", SOUND_BASE, g_Songs[songIdx].filePath);

    for (int i = 1; i <= MaxClients; i++)
    {
        if (!IsClientInGame(i)) continue;
        StopClientMusic(i);
        EmitSoundToClient(i, fullPath, SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_NORMAL);
        g_CurrentSong[i]   = songIdx;
        g_SongStartTime[i] = GetGameTime();
    }

    // Notificação global
    NotifyMusicStartAll(songIdx, requester);

    // Timer global (usa slot 0)
    if (g_Songs[songIdx].duration > 0.0)
    {
        DataPack dp = new DataPack();
        dp.WriteCell(0); // 0 = todos
        dp.WriteCell(songIdx);
        CreateDataTimer(g_Songs[songIdx].duration, Timer_SongEnd, dp);
    }

    // Letras globais
    if (g_cvLyricsEnabled.BoolValue)
        LoadAndScheduleLyrics(songIdx, -1);

    // HUD pra todos
    CreateTimer(0.1, Timer_UpdateHUDAll, _, TIMER_REPEAT | TIMER_FLAG_NO_MAPCHANGE);
}

void StopClientMusic(int client)
{
    if (g_CurrentSong[client] == -1) return;

    char fullPath[PLATFORM_MAX_PATH];
    Format(fullPath, sizeof(fullPath), "%s%s", SOUND_BASE, g_Songs[g_CurrentSong[client]].filePath);

    StopSound(client, SNDCHAN_AUTO, fullPath);

    g_CurrentSong[client] = -1;

    if (g_SongTimer[client] != null)
    {
        delete g_SongTimer[client];
        g_SongTimer[client] = null;
    }

    ClearSyncHud(client, g_HudSync);
}

// ============================================================
// Notificações
// ============================================================
void NotifyMusicStart(int target, int songIdx, int requester)
{
    char reqName[MAX_NAME_LENGTH];
    GetClientName(requester, reqName, sizeof(reqName));

    char mode[32];
    if (requester == target)
        Format(mode, sizeof(mode), "para si mesmo");
    else
        Format(mode, sizeof(mode), "para você");

    if (g_cvNotifyChat.BoolValue)
        PrintToChat(target, "\x01[Music] \x04♪ %s\x01 — %s \x05(%s por %s)",
            g_Songs[songIdx].displayName,
            g_Songs[songIdx].category,
            mode, reqName);

    if (g_cvNotifyHint.BoolValue)
    {
        char hint[256];
        Format(hint, sizeof(hint), "♪ Tocando agora: %s\n%s",
            g_Songs[songIdx].displayName,
            g_Songs[songIdx].category);
        PrintHintText(target, hint);
    }
}

void NotifyMusicStartAll(int songIdx, int requester)
{
    char reqName[MAX_NAME_LENGTH];
    GetClientName(requester, reqName, sizeof(reqName));

    for (int i = 1; i <= MaxClients; i++)
    {
        if (!IsClientInGame(i)) continue;

        if (g_cvNotifyChat.BoolValue)
            PrintToChat(i, "\x01[Music] \x04♪ %s\x01 — %s \x05(para todos, por %s)",
                g_Songs[songIdx].displayName,
                g_Songs[songIdx].category,
                reqName);

        if (g_cvNotifyHint.BoolValue)
        {
            char hint[256];
            Format(hint, sizeof(hint), "♪ Tocando agora: %s\n%s",
                g_Songs[songIdx].displayName,
                g_Songs[songIdx].category);
            PrintHintText(i, hint);
        }
    }
}

// ============================================================
// HUD Text (canto inferior esquerdo)
// ============================================================
public Action Timer_UpdateHUD(Handle timer, int client)
{
    if (!IsClientInGame(client) || g_CurrentSong[client] == -1)
        return Plugin_Stop;

    if (!g_ShowHUD[client])
        return Plugin_Continue;

    int songIdx = g_CurrentSong[client];
    float elapsed = GetGameTime() - g_SongStartTime[client];
    int elSec = RoundToFloor(elapsed);
    int min = elSec / 60;
    int sec = elSec % 60;

    char hudText[256];
    if (g_Songs[songIdx].duration > 0.0)
    {
        int total = RoundToFloor(g_Songs[songIdx].duration);
        Format(hudText, sizeof(hudText), "♪ %s\n  %s  [%02d:%02d / %02d:%02d]",
            g_Songs[songIdx].displayName,
            g_Songs[songIdx].category,
            min, sec,
            total / 60, total % 60);
    }
    else
    {
        Format(hudText, sizeof(hudText), "♪ %s\n  %s  [%02d:%02d]",
            g_Songs[songIdx].displayName,
            g_Songs[songIdx].category,
            min, sec);
    }

    SetHudTextParams(HUD_X, HUD_Y, 0.2, 200, 220, 255, 255);
    ShowSyncHudText(client, g_HudSync, hudText);

    return Plugin_Continue;
}

public Action Timer_UpdateHUDAll(Handle timer)
{
    bool anyPlaying = false;
    for (int i = 1; i <= MaxClients; i++)
    {
        if (!IsClientInGame(i)) continue;
        if (g_CurrentSong[i] == -1) continue;
        if (!g_ShowHUD[i]) continue;

        anyPlaying = true;

        int songIdx = g_CurrentSong[i];
        float elapsed = GetGameTime() - g_SongStartTime[i];
        int elSec = RoundToFloor(elapsed);
        int min = elSec / 60;
        int sec = elSec % 60;

        char hudText[256];
        Format(hudText, sizeof(hudText), "♪ %s\n  %s  [%02d:%02d]",
            g_Songs[songIdx].displayName,
            g_Songs[songIdx].category,
            min, sec);

        SetHudTextParams(HUD_X, HUD_Y, 0.2, 200, 220, 255, 255);
        ShowSyncHudText(i, g_HudSync, hudText);
    }

    return anyPlaying ? Plugin_Continue : Plugin_Stop;
}

// ============================================================
// Timer: fim da música
// ============================================================
public Action Timer_SongEnd(Handle timer, DataPack dp)
{
    dp.Reset();
    int target  = dp.ReadCell();
    int songIdx = dp.ReadCell();

    if (target == 0)
    {
        // Era para todos
        for (int i = 1; i <= MaxClients; i++)
        {
            if (IsClientInGame(i) && g_CurrentSong[i] == songIdx)
            {
                g_CurrentSong[i] = -1;
                g_SongTimer[i]   = null;
                ClearSyncHud(i, g_HudSync);
            }
        }
    }
    else
    {
        if (IsClientInGame(target) && g_CurrentSong[target] == songIdx)
        {
            g_CurrentSong[target] = -1;
            g_SongTimer[target]   = null;
            ClearSyncHud(target, g_HudSync);
        }
    }

    return Plugin_Stop;
}

// ============================================================
// Sistema de letras sincronizadas (desativado por padrão)
// ============================================================
void LoadAndScheduleLyrics(int songIdx, int target)
{
    // Cancela timers anteriores de letras
    for (int i = 0; i < g_LyricCount; i++)
    {
        if (g_LyricTimers[i] != null)
        {
            delete g_LyricTimers[i];
            g_LyricTimers[i] = null;
        }
    }
    g_LyricCount  = 0;
    g_LyricTarget = target;

    // Monta caminho do arquivo de letra
    char fileName[PLATFORM_MAX_PATH];
    strcopy(fileName, sizeof(fileName), g_Songs[songIdx].filePath);
    // Remove extensão e adiciona .txt
    int dot = -1;
    for (int i = strlen(fileName) - 1; i >= 0; i--)
    {
        if (fileName[i] == '.') { dot = i; break; }
    }
    if (dot >= 0) fileName[dot] = '\0';

    char lyricsPath[PLATFORM_MAX_PATH];
    BuildPath(Path_SM, lyricsPath, sizeof(lyricsPath), "%s%s.txt", LYRICS_DIR, fileName);

    File f = OpenFile(lyricsPath, "r");
    if (f == null) return; // sem letra — tudo bem

    char line[512];
    while (f.ReadLine(line, sizeof(line)) && g_LyricCount < MAX_LYRICS_LINES)
    {
        TrimString(line);
        if (line[0] == '\0' || line[0] == '/') continue;

        char parts[2][256];
        if (ExplodeString(line, "|", parts, 2, 256) < 2) continue;

        g_Lyrics[g_LyricCount].timestamp = StringToFloat(parts[0]);
        strcopy(g_Lyrics[g_LyricCount].text, 256, parts[1]);

        // Agenda o timer para essa linha
        DataPack dp = new DataPack();
        dp.WriteCell(g_LyricCount);
        g_LyricTimers[g_LyricCount] = CreateDataTimer(
            g_Lyrics[g_LyricCount].timestamp,
            Timer_ShowLyric,
            dp
        );

        g_LyricCount++;
    }
    delete f;
}

public Action Timer_ShowLyric(Handle timer, DataPack dp)
{
    dp.Reset();
    int idx = dp.ReadCell();
    g_LyricTimers[idx] = null;

    if (g_LyricTarget == -1)
    {
        // Para todos
        for (int i = 1; i <= MaxClients; i++)
            if (IsClientInGame(i))
                PrintCenterText(i, "%s", g_Lyrics[idx].text);
    }
    else
    {
        if (IsClientInGame(g_LyricTarget))
            PrintCenterText(g_LyricTarget, "%s", g_Lyrics[idx].text);
    }

    return Plugin_Stop;
}

// ============================================================
// Eventos de Tank
// ============================================================
public Action Event_TankSpawn(Event event, const char[] name, bool dontBroadcast)
{
    g_TankAlive = true;

    // Bloqueia música do Tank via hook de sound
    // A mensagem substitui visualmente a música
    char tankMsg[256];
    g_cvTankMessage.GetString(tankMsg, sizeof(tankMsg));

    for (int i = 1; i <= MaxClients; i++)
    {
        if (!IsClientInGame(i)) continue;
        PrintHintText(i, tankMsg);
        PrintToChat(i, "\x01[!] \x04%s", tankMsg);
    }

    return Plugin_Continue;
}

public Action Event_TankKilled(Event event, const char[] name, bool dontBroadcast)
{
    g_TankAlive = false;

    char deadMsg[256];
    g_cvTankDeadMessage.GetString(deadMsg, sizeof(deadMsg));

    for (int i = 1; i <= MaxClients; i++)
    {
        if (!IsClientInGame(i)) continue;
        PrintHintText(i, deadMsg);
        PrintToChat(i, "\x01[!] \x04%s", deadMsg);
    }

    return Plugin_Continue;
}

// Bloqueia música do Tank (hook de EmitSound)
public Action OnNormalSoundHook(int clients[MAXPLAYERS], int &numClients,
    char sample[PLATFORM_MAX_PATH], int &entity, int &channel,
    float &volume, int &level, int &pitch, int &flags,
    char soundEntry[PLATFORM_MAX_PATH], int &seed)
{
    // Músicas do Tank ficam em npc/tank/
    if (StrContains(sample, "npc/tank/", false) != -1 && g_TankAlive)
        return Plugin_Stop; // bloqueia

    return Plugin_Continue;
}
